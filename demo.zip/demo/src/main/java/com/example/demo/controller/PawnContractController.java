package com.example.demo.controller;

import com.example.demo.dto.PawnContractDto;
import com.example.demo.entity.*;
import com.example.demo.service.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@WebServlet(name = "PawnContractController", urlPatterns = "/pawn-contracts")
public class PawnContractController extends HttpServlet {

    private final IPawnContractService pawnContractService = new PawnContractService();
    private final IAccountService accountService = new AccountService();
    private final ICustomerService customerService = new CustomerService();
    private final IEmployeeService employeeService = new EmployeeService();
    private final IProductService productService = new ProductService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "";

        switch (action) {
            case "create":
                showCreateForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deletePawnContract(request, response);
                break;
            default:
                listPawnContracts(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "";

        switch (action) {
            case "create":
                createPawnContract(request, response);
                break;
            case "edit":
                updatePawnContract(request, response);
                break;
            default:
                listPawnContracts(request, response);
                break;
        }
    }

    // ====================== LIST ======================
    private void listPawnContracts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String customerName = request.getParameter("customerName");
        String employeeName = request.getParameter("employeeName");
        String productName = request.getParameter("productName");

        int page = 1;
        int recordsPerPage = 5;
        String pageParam = request.getParameter("page");
        if (pageParam != null && !pageParam.trim().isEmpty()) {
            try {
                page = Integer.parseInt(pageParam);
                if (page < 1) page = 1;
            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        List<PawnContractDto> contracts;
        int totalRecords;

        boolean hasSearch = (customerName != null && !customerName.trim().isEmpty()) ||
                (employeeName != null && !employeeName.trim().isEmpty()) ||
                (productName != null && !productName.trim().isEmpty());

        if (hasSearch) {
            contracts = pawnContractService.search(customerName, employeeName, productName);
            totalRecords = contracts.size();
        } else {
            totalRecords = pawnContractService.countPawnContract();
            int offset = (page - 1) * recordsPerPage;
            contracts = pawnContractService.findAll(offset, recordsPerPage);
        }

        int totalPages = (int) Math.ceil((double) totalRecords / recordsPerPage);
        request.setAttribute("pawnContracts", contracts);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("customerName", customerName);
        request.setAttribute("employeeName", employeeName);
        request.setAttribute("productName", productName);

        request.getRequestDispatcher("views/pawn_contract/list.jsp").forward(request, response);
    }

    // ====================== CREATE ======================
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Load danh sách nhân viên để hiển thị select
        List<Employee> employees = employeeService.getAllEmployees();
        request.setAttribute("employees", employees);

        String phoneOrCCCD = request.getParameter("phoneOrCCCD");
        if (phoneOrCCCD != null && !phoneOrCCCD.trim().isEmpty()) {
            Customer existingCustomer = customerService.findByPhoneOrCCCD(phoneOrCCCD.trim());
            request.setAttribute("existingCustomer", existingCustomer);
        }

        // FIX: Nếu có lỗi (ERROR attribute được set), thì lấy lại tất cả tham số POST
        if (request.getAttribute("error") != null) {
            // Dữ liệu hợp đồng (luôn phải có)
            request.setAttribute("employeeId", request.getParameter("employeeId"));
            request.setAttribute("pawnAmount", request.getParameter("pawnAmount"));
            request.setAttribute("interestRate", request.getParameter("interestRate"));
            request.setAttribute("pawnDate", request.getParameter("pawnDate"));
            request.setAttribute("dueDate", request.getParameter("dueDate"));

            // Dữ liệu sản phẩm
            request.setAttribute("productName", request.getParameter("productName"));
            request.setAttribute("description", request.getParameter("description"));
            request.setAttribute("productValue", request.getParameter("productValue"));

            // Dữ liệu khách hàng mới (nếu khối tạo KH mới bị lỗi)
            request.setAttribute("username", request.getParameter("username"));
            request.setAttribute("fullName", request.getParameter("fullName"));
            request.setAttribute("citizenNumber", request.getParameter("citizenNumber"));
            request.setAttribute("address", request.getParameter("address"));
            request.setAttribute("email", request.getParameter("email"));
            request.setAttribute("dob", request.getParameter("dob"));
            // (Không lưu lại password)
        }


        request.getRequestDispatcher("views/pawn_contract/add.jsp").forward(request, response);

    }

    private void createPawnContract(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Biến này được đặt ở đây để đảm bảo giá trị của nó được parse trước mọi logic phức tạp.
        int employeeId = 0;
        try {
            // LƯU Ý QUAN TRỌNG: Giá trị này phải được lấy thành công, nếu không sẽ lỗi parameter 2.
            // Nếu giá trị này bị null, nó sẽ ném ra IllegalArgumentException ngay lập tức
            employeeId = parseIntParameter(request.getParameter("employeeId"), "Mã nhân viên không hợp lệ");

            // ===== SAO LƯU DỮ LIỆU ĐÃ NHẬP VÀO ATTRIBUTE NGAY TỪ ĐẦU (ĐỂ SỬA LỖI LẶP LẠI) =====
            request.setAttribute("employeeId", String.valueOf(employeeId));
            request.setAttribute("pawnAmount", request.getParameter("pawnAmount"));
            request.setAttribute("interestRate", request.getParameter("interestRate"));
            request.setAttribute("pawnDate", request.getParameter("pawnDate"));
            request.setAttribute("dueDate", request.getParameter("dueDate"));
            request.setAttribute("productName", request.getParameter("productName"));
            request.setAttribute("description", request.getParameter("description"));
            request.setAttribute("productValue", request.getParameter("productValue"));
            request.setAttribute("username", request.getParameter("username"));
            request.setAttribute("fullName", request.getParameter("fullName"));
            request.setAttribute("citizenNumber", request.getParameter("citizenNumber"));
            request.setAttribute("address", request.getParameter("address"));
            request.setAttribute("email", request.getParameter("email"));
            request.setAttribute("dob", request.getParameter("dob"));
            // =================================================================================

            // ===== 1. Lấy số điện thoại hoặc CCCD =====
            String phoneOrCCCD = request.getParameter("phoneOrCCCD");
            if (phoneOrCCCD == null || phoneOrCCCD.trim().isEmpty()) {
                throw new IllegalArgumentException("Số điện thoại hoặc CCCD bắt buộc");
            }
            phoneOrCCCD = phoneOrCCCD.trim();

            // ===== 2. Kiểm tra khách hàng =====
            Customer customer = customerService.findByPhoneOrCCCD(phoneOrCCCD);
            if (customer == null) {
                // ===== 2a. Lấy thông tin khách hàng mới =====
                String username = request.getParameter("username");
                String password = request.getParameter("password");
                String fullName = request.getParameter("fullName");
                String citizenNumber = request.getParameter("citizenNumber");
                String address = request.getParameter("address");
                String email = request.getParameter("email");
                String dobStr = request.getParameter("dob");

                if (username == null || username.trim().isEmpty() ||
                        password == null || password.trim().isEmpty() ||
                        fullName == null || fullName.trim().isEmpty() ||
                        citizenNumber == null || citizenNumber.trim().isEmpty()) {
                    throw new IllegalArgumentException("Thông tin khách hàng mới không được để trống");
                }

                // ===== 2b. Tạo account =====
                // Giả định Account constructor là (username, password, role)
                Account account = new Account(username.trim(), password.trim(), Account.Role.USER);
                accountService.createAccount(account); // accountId đã có

                // ===== 2c. Tạo customer =====
                customer = new Customer(
                        account.getAccountId(),
                        fullName.trim(),
                        citizenNumber.trim(),
                        phoneOrCCCD,
                        address != null ? address.trim() : null,
                        email != null ? email.trim() : null,
                        dobStr != null && !dobStr.isEmpty() ? LocalDate.parse(dobStr) : null
                );
                customerService.createCustomer(customer); // customerId đã có
            }

            // LƯU Ý: Customer ID được lấy/tạo thành công

            // ===== 3. Tạo sản phẩm =====
            String productName = request.getParameter("productName");
            String description = request.getParameter("description");
            BigDecimal productValue = parseBigDecimalParameter(request.getParameter("productValue"), "Giá trị sản phẩm không hợp lệ");

            if (productName == null || productName.trim().isEmpty()) {
                throw new IllegalArgumentException("Tên sản phẩm không được để trống");
            }

            Product product = new Product();
            product.setProductName(productName.trim());
            product.setDescription(description != null ? description.trim() : null);
            product.setPawnPrice(productValue);
            product.setStatus(Product.Status.DANG_CAM);

            productService.create(product); // productId đã có
            if (product.getProductId() <= 0) {
                throw new RuntimeException("Không lấy được ID của sản phẩm vừa tạo");
            }

            // ===== 4. Lấy thông tin hợp đồng (Còn lại) =====
            BigDecimal pawnPrice = parseBigDecimalParameter(request.getParameter("pawnAmount"), "Số tiền cầm không hợp lệ");
            BigDecimal interestRate = parseBigDecimalParameter(request.getParameter("interestRate"), "Lãi suất không hợp lệ");
            LocalDate pawnDate = parseLocalDateParameter(request.getParameter("pawnDate"), "Ngày cầm không hợp lệ");
            LocalDate dueDate = parseLocalDateParameter(request.getParameter("dueDate"), "Ngày đến hạn không hợp lệ");


            // Đã có employeeId từ đầu

            if (pawnPrice.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("Số tiền cầm phải lớn hơn 0");
            }
            if (pawnDate.isBefore(LocalDate.now())) {
                throw new IllegalArgumentException("Ngày cầm không được trước hôm nay");
            }
            if (!dueDate.isAfter(pawnDate)) {
                throw new IllegalArgumentException("Ngày đến hạn phải sau ngày cầm");
            }

            // ===== 5. Tạo hợp đồng =====
            PawnContract contract = new PawnContract(
                    customer.getCustomerId(),
                    employeeId, // Tham số 2 ĐÃ được set ở đầu phương thức
                    product.getProductId(),
                    pawnDate,
                    pawnPrice,
                    interestRate,
                    dueDate,
                    null // returnDate chưa có
            );

            boolean success = pawnContractService.add(contract);
            if (!success) {
                throw new RuntimeException("Không thể thêm hợp đồng cầm");
            }

            response.sendRedirect(request.getContextPath() + "/pawn-contracts?message=created");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi thêm hợp đồng: " + e.getMessage());
            // FIX: GỌI LẠI showCreateForm (NÓ SẼ LẤY LẠI THAM SỐ TỪ REQUEST)
            // LƯU Ý: Khối catch này gọi lại showCreateForm, nó sẽ lấy lại các tham số POST bị mất
            showCreateForm(request, response);
        }
    }



    // ====================== EDIT / UPDATE ======================
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = parseIntParameter(request.getParameter("id"), "Mã hợp đồng không hợp lệ");
            PawnContractDto contract = pawnContractService.findById(id);
            if (contract == null) {
                request.setAttribute("error", "Không tìm thấy hợp đồng với ID: " + id);
                request.getRequestDispatcher("views/pawn_contract/list.jsp").forward(request, response);
                return;
            }
            // Load danh sách nhân viên để select
            List<Employee> employees = employeeService.getAllEmployees();
            request.setAttribute("employees", employees);

            request.setAttribute("contract", contract);
            request.getRequestDispatcher("views/pawn_contract/update.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "Lỗi: " + e.getMessage());
            request.getRequestDispatcher("views/pawn_contract/list.jsp").forward(request, response);
        }
    }

    private void updatePawnContract(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            PawnContract contract = new PawnContract();
            contract.setPawnContractId(parseIntParameter(request.getParameter("id"), "Mã hợp đồng không hợp lệ"));
            contract.setCustomerId(parseIntParameter(request.getParameter("customerId"), "Mã khách hàng không hợp lệ"));
            contract.setEmployeeId(parseIntParameter(request.getParameter("employeeId"), "Mã nhân viên không hợp lệ"));
            contract.setProductId(parseIntParameter(request.getParameter("productId"), "Mã sản phẩm không hợp lệ"));
            contract.setPawnPrice(parseBigDecimalParameter(request.getParameter("pawnPrice"), "Giá cầm không hợp lệ"));
            contract.setInterestRate(parseBigDecimalParameter(request.getParameter("interestRate"), "Lãi suất không hợp lệ"));
            contract.setPawnDate(parseLocalDateParameter(request.getParameter("pawnDate"), "Ngày cầm không hợp lệ"));
            contract.setDueDate(parseLocalDateParameter(request.getParameter("dueDate"), "Ngày đến hạn không hợp lệ"));
            String returnDateStr = request.getParameter("returnDate");
            contract.setReturnDate(returnDateStr != null && !returnDateStr.trim().isEmpty() ?
                    LocalDate.parse(returnDateStr) : null);

            boolean success = pawnContractService.update(contract);
            if (!success) throw new RuntimeException("Không thể cập nhật hợp đồng cầm");

            response.sendRedirect(request.getContextPath() + "/pawn-contracts?message=updated");
        } catch (Exception e) {
            request.setAttribute("error", "Lỗi khi cập nhật hợp đồng: " + e.getMessage());
            showEditForm(request, response);
        }
    }

    // ====================== DELETE ======================
    private void deletePawnContract(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        try {
            int id = parseIntParameter(request.getParameter("id"), "Mã hợp đồng không hợp lệ");
            boolean success = pawnContractService.delete(id);
            if (!success) throw new RuntimeException("Không thể xóa hợp đồng cầm");
            response.sendRedirect(request.getContextPath() + "/pawn-contracts?message=deleted");
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/pawn-contracts?error=" + e.getMessage());
        }
    }

    // ====================== UTILS ======================
    private int parseIntParameter(String value, String errorMessage) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(errorMessage);
        try {
            int result = Integer.parseInt(value);
            // FIX: Loại bỏ lỗi <= 0 nếu đó là ID tự tăng
            // Nếu bạn đang lấy ID nhân viên từ Select Box, giá trị ID luôn phải > 0
            if (result <= 0) throw new IllegalArgumentException(errorMessage);
            return result;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(errorMessage);
        }
    }

    private BigDecimal parseBigDecimalParameter(String value, String errorMessage) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(errorMessage);
        try {
            return new BigDecimal(value);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(errorMessage);
        }
    }

    private LocalDate parseLocalDateParameter(String value, String errorMessage) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(errorMessage);
        try {
            return LocalDate.parse(value);
        } catch (Exception e) {
            throw new IllegalArgumentException(errorMessage);
        }
    }
}
