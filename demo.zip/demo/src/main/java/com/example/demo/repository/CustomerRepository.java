package com.example.demo.repository;

import com.example.demo.entity.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerRepository {

    // Thêm khách hàng mới
    public boolean add(Customer customer) {
        String sql = "INSERT INTO customer (account_id, full_name, citizen_number, phone_number, address, email, dob) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = BaseRepository.getConnectDB();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // Các giá trị bắt buộc
            stmt.setInt(1, customer.getAccountId());
            stmt.setString(2, customer.getFullName());
            stmt.setString(3, customer.getCitizenNumber());
            stmt.setString(4, customer.getPhoneNumber());

            // Các giá trị có thể null, nếu null thì set rỗng hoặc setNull
            if (customer.getAddress() != null && !customer.getAddress().isEmpty()) {
                stmt.setString(5, customer.getAddress());
            } else {
                stmt.setNull(5, Types.VARCHAR);
            }

            if (customer.getEmail() != null && !customer.getEmail().isEmpty()) {
                stmt.setString(6, customer.getEmail());
            } else {
                stmt.setNull(6, Types.VARCHAR);
            }

            if (customer.getDob() != null) {
                stmt.setDate(7, Date.valueOf(customer.getDob()));
            } else {
                stmt.setNull(7, Types.DATE);
            }

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        customer.setCustomerId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;

        } catch (SQLException e) {
            throw new RuntimeException("Lỗi SQL khi thêm Customer: " + e.getMessage(), e);
        }
    }


    // Tìm theo ID
    public Customer findById(int id) {
        String sql = "SELECT * FROM customer WHERE customer_id = ?";
        try (Connection conn = BaseRepository.getConnectDB();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapToCustomer(rs);
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Tìm theo CMND
    public Customer findByCitizenNumber(String citizenNumber) {
        String sql = "SELECT * FROM customer " +
                "WHERE REPLACE(TRIM(phone_number), ' ', '') = REPLACE(?, ' ', '') " +
                "   OR REPLACE(TRIM(citizen_number), ' ', '') = REPLACE(?, ' ', '')";

        try (Connection conn = BaseRepository.getConnectDB();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, citizenNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapToCustomer(rs);
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Tìm theo số điện thoại hoặc CCCD (loại bỏ khoảng trắng đầu/cuối, case-insensitive)
    public Customer findByPhoneOrCCCD(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        value = value.trim();

        String sql = "SELECT * FROM customer " +
                "WHERE TRIM(phone_number) = ? OR TRIM(citizen_number) = ?";
        try (Connection conn = BaseRepository.getConnectDB();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, value);
            stmt.setString(2, value);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapToCustomer(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Lỗi SQL khi tìm Customer: " + e.getMessage(), e);
        }
        return null;
    }


    // Lấy tất cả
    public List<Customer> findAll() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customer";
        try (Connection conn = BaseRepository.getConnectDB();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapToCustomer(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    // Mapping ResultSet -> Customer
    private Customer mapToCustomer(ResultSet rs) throws SQLException {
        return new Customer(
                rs.getInt("customer_id"),
                rs.getInt("account_id"),
                rs.getString("full_name"),
                rs.getString("citizen_number"),
                rs.getString("phone_number"),
                rs.getString("address"),
                rs.getString("email"),
                rs.getDate("dob") != null ? rs.getDate("dob").toLocalDate() : null
        );
    }
}
