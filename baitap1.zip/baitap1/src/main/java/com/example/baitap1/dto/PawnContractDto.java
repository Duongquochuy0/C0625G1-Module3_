package com.example.baitap1.dto;

import java.time.LocalDate;

public class PawnContractDto {
    private int pawnContractId;
    private int customerId;
    private int employeeId;
    private int productId;
    private double pawnValue;
    private double interestRate;
    private LocalDate pawnDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private String status;
    private String customerName;
    private String customerPhone;
    private String productName;
    private String employeeName;

    public PawnContractDto() {
    }
    public PawnContractDto(int pawnContractId, int customerId, int employeeId, int productId, double pawnValue, double interestRate, LocalDate pawnDate, LocalDate dueDate, LocalDate returnDate, String status, String customerName, String customerPhone, String productName, String employeeName) {
        this.pawnContractId = pawnContractId;
        this.customerId = customerId;
        this.employeeId = employeeId;
        this.productId = productId;
        this.pawnValue = pawnValue;
        this.interestRate = interestRate;
        this.pawnDate = pawnDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.status = status;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.productName = productName;
        this.employeeName = employeeName;
    }

    public int getPawnContractId() {
        return pawnContractId;
    }

    public void setPawnContractId(int pawnContractId) {
        this.pawnContractId = pawnContractId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public double getPawnValue() {
        return pawnValue;
    }

    public void setPawnValue(double pawnValue) {
        this.pawnValue = pawnValue;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public LocalDate getPawnDate() {
        return pawnDate;
    }

    public void setPawnDate(LocalDate pawnDate) {
        this.pawnDate = pawnDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }
}
