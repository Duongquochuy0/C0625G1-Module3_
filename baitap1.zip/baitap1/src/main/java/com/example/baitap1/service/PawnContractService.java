package com.example.baitap1.service;

import com.example.baitap1.dto.PawnContractDto;
import com.example.baitap1.entity.PawnContract;
import com.example.baitap1.repository.IPawnContractRepository;
import com.example.baitap1.repository.PawnContractRepository;

import java.util.List;

public class PawnContractService implements IPawnContractService {
    private final IPawnContractRepository pawnContractRepository = new PawnContractRepository();

    @Override
    public List<PawnContractDto> findAllContractsDto() {
        return pawnContractRepository.findAllContractsDto();
    }

    @Override
    public PawnContractDto findContractDtoById(int id) {
        return pawnContractRepository.findContractDtoById(id);
    }

    @Override
    public boolean addContract(PawnContract contract) {
        return pawnContractRepository.addContract(contract);
    }

    @Override
    public boolean updateContract(PawnContract contract) {
        return pawnContractRepository.updateContract(contract);
    }

    @Override
    public boolean deleteContract(int id) {
        return pawnContractRepository.deleteContract(id);
    }

    @Override
    public List<PawnContractDto> searchContractsDto(String keyword) {
        return pawnContractRepository.searchContractsDto(keyword);
    }
}
