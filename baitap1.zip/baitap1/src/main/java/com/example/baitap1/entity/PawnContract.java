package com.example.baitap1.entity;

import java.time.LocalDate;

public class PawnContract {
    private int pawnContractId;
    private int customerId;
    private int employeeId;
    private int productId;
    private double pawnValue;
    private double interestRate;
    private LocalDate pawnDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private String status;

    public PawnContract() {}

    public PawnContract(int pawnContractId, int customerId, int employeeId, int productId,
                        double pawnValue, double interestRate,
                        LocalDate pawnDate, LocalDate dueDate,
                        LocalDate returnDate, String status) {
        this.pawnContractId = pawnContractId;
        this.customerId = customerId;
        this.employeeId = employeeId;
        this.productId = productId;
        this.pawnValue = pawnValue;
        this.interestRate = interestRate;
        this.pawnDate = pawnDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.status = status;
    }

    public int getPawnContractId() {
        return pawnContractId;
    }

    public void setPawnContractId(int pawnContractId) {
        this.pawnContractId = pawnContractId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public double getPawnValue() {
        return pawnValue;
    }

    public void setPawnValue(double pawnValue) {
        this.pawnValue = pawnValue;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public LocalDate getPawnDate() {
        return pawnDate;
    }

    public void setPawnDate(LocalDate pawnDate) {
        this.pawnDate = pawnDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
