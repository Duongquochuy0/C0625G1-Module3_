package com.example.baitap1.repository;

import com.example.baitap1.dto.PawnContractDto;
import com.example.baitap1.entity.PawnContract;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PawnContractRepository implements IPawnContractRepository {
    private static final String SELECT_CONTRACTS_DTO_SQL =
            "SELECT \n" +
                    "    c.pawn_contract_id,\n" +
                    "    cu.customer_id,\n" +
                    "    cu.full_name AS customer_name,\n" +
                    "    cu.phone_number AS customer_phone,\n" +
                    "    c.employee_id,\n" +
                    "    e.full_name AS employee_name,\n" +
                    "    c.product_id,\n" +
                    "    p.product_name,\n" +
                    "    c.pawn_price,\n" +
                    "    c.interest_rate,\n" +
                    "    c.pawn_date,\n" +
                    "    c.due_date,\n" +
                    "    c.return_date,\n" +
                    "    p.status AS product_status\n" +
                    "FROM pawn_contract c\n" +
                    "JOIN customer cu ON c.customer_id = cu.customer_id\n" +
                    "JOIN employee e ON c.employee_id = e.employee_id\n" +
                    "JOIN product p ON c.product_id = p.product_id;\n";

    private static final String INSERT_CONTRACT_SQL =
            "INSERT INTO pawn_contract (customer_id, employee_id, product_id, pawn_date, pawn_price, interest_rate, due_date, return_date) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_CONTRACT_SQL =
            "UPDATE pawn_contract SET customer_id=?, employee_id=?, product_id=?, pawn_date=?, pawn_price=?, interest_rate=?, due_date=?, return_date=? " +
                    "WHERE pawn_contract_id = ?";

    private static final String DELETE_CONTRACT_SQL =
            "DELETE FROM pawn_contract WHERE pawn_contract_id = ?";

    private static final String SELECT_CONTRACT_BY_ID_DTO =
            SELECT_CONTRACTS_DTO_SQL + " WHERE c.pawn_contract_id = ?";

    private static final String SEARCH_CONTRACTS_DTO_SQL =
            SELECT_CONTRACTS_DTO_SQL + " WHERE cu.full_name LIKE ? OR p.product_name LIKE ? OR CAST(c.pawn_contract_id AS CHAR) LIKE ?";

    @Override
    public List<PawnContractDto> findAllContractsDto() {
        List<PawnContractDto> list = new ArrayList<>();
        try (Connection connection = BaseRepository.getConnectDB();
             PreparedStatement ps = connection.prepareStatement(SELECT_CONTRACTS_DTO_SQL)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapToDto(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public PawnContractDto findContractDtoById(int id) {
        try (Connection connection = BaseRepository.getConnectDB();
             PreparedStatement ps = connection.prepareStatement(SELECT_CONTRACT_BY_ID_DTO)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapToDto(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean addContract(PawnContract contract) {
        try (Connection connection = BaseRepository.getConnectDB();
             PreparedStatement ps = connection.prepareStatement(INSERT_CONTRACT_SQL)) {
            ps.setInt(1, contract.getCustomerId());
            ps.setInt(2, contract.getEmployeeId());
            ps.setInt(3, contract.getProductId());
            ps.setDate(4, Date.valueOf(contract.getPawnDate())); // LocalDate -> sql.Date
            ps.setDouble(5, contract.getPawnValue());
            ps.setDouble(6, contract.getInterestRate());
            ps.setDate(7, Date.valueOf(contract.getDueDate()));
            if (contract.getReturnDate() != null) {
                ps.setDate(8, Date.valueOf(contract.getReturnDate()));
            } else {
                ps.setNull(8, Types.DATE);
            }
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateContract(PawnContract contract) {
        try (Connection connection = BaseRepository.getConnectDB();
             PreparedStatement ps = connection.prepareStatement(UPDATE_CONTRACT_SQL)) {
            ps.setInt(1, contract.getCustomerId());
            ps.setInt(2, contract.getEmployeeId());
            ps.setInt(3, contract.getProductId());
            ps.setDate(4, Date.valueOf(contract.getPawnDate()));
            ps.setDouble(5, contract.getPawnValue());
            ps.setDouble(6, contract.getInterestRate());
            ps.setDate(7, Date.valueOf(contract.getDueDate()));
            if (contract.getReturnDate() != null) {
                ps.setDate(8, Date.valueOf(contract.getReturnDate()));
            } else {
                ps.setNull(8, Types.DATE);
            }
            ps.setInt(9, contract.getPawnContractId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteContract(int id) {
        try (Connection connection = BaseRepository.getConnectDB();
             PreparedStatement ps = connection.prepareStatement(DELETE_CONTRACT_SQL)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<PawnContractDto> searchContractsDto(String keyword) {
        List<PawnContractDto> list = new ArrayList<>();
        try (Connection connection = BaseRepository.getConnectDB();
             PreparedStatement ps = connection.prepareStatement(SEARCH_CONTRACTS_DTO_SQL)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapToDto(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    private PawnContractDto mapToDto(ResultSet rs) throws SQLException {
        PawnContractDto dto = new PawnContractDto();
        dto.setPawnContractId(rs.getInt("pawn_contract_id"));
        dto.setCustomerId(rs.getInt("customer_id"));
        dto.setCustomerName(rs.getString("customer_name"));
        dto.setCustomerPhone(rs.getString("customer_phone"));
        dto.setEmployeeId(rs.getInt("employee_id"));
        dto.setEmployeeName(rs.getString("employee_name"));
        dto.setProductId(rs.getInt("product_id"));
        dto.setProductName(rs.getString("product_name"));
        dto.setPawnValue(rs.getDouble("pawn_price"));
        dto.setInterestRate(rs.getDouble("interest_rate"));

        Date pawnDate = rs.getDate("pawn_date");
        if (pawnDate != null) dto.setPawnDate(pawnDate.toLocalDate());

        Date dueDate = rs.getDate("due_date");
        if (dueDate != null) dto.setDueDate(dueDate.toLocalDate());

        Date returnDate = rs.getDate("return_date");
        if (returnDate != null) dto.setReturnDate(returnDate.toLocalDate());

        dto.setStatus(rs.getString("product_status")); // ✅ lấy từ alias
        return dto;
    }
}
