package com.example.baitap1.service;

import com.example.baitap1.dto.PawnContractDto;
import com.example.baitap1.entity.PawnContract;

import java.util.List;

public interface IPawnContractService {
    List<PawnContractDto> findAllContractsDto();
    PawnContractDto findContractDtoById(int id);
    boolean addContract(PawnContract contract);
    boolean updateContract(PawnContract contract);
    boolean deleteContract(int id);
    List<PawnContractDto> searchContractsDto(String keyword);
}
