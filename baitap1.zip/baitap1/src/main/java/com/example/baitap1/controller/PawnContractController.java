package com.example.baitap1.controller;

import com.example.baitap1.dto.PawnContractDto;
import com.example.baitap1.entity.PawnContract;
import com.example.baitap1.service.IPawnContractService;
import com.example.baitap1.service.PawnContractService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@WebServlet(name = "PawnContractServlet", urlPatterns = "/admin/contracts")
public class PawnContractController extends HttpServlet {
    private final IPawnContractService pawnContractService = new PawnContractService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "view":
                viewContract(request, response);
                break;
            case "delete":
                deleteContract(request, response);
                break;
            case "search":
                searchContracts(request, response);
                break;
            case "createForm":
                request.getRequestDispatcher("/views/pawncontract/create.jsp").forward(request, response);

                break;
            case "updateForm":
                showUpdateForm(request, response);
                break;
            default:
                listContracts(request, response);
                break;
        }
    }

    private void listContracts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<PawnContractDto> contracts = pawnContractService.findAllContractsDto();
        request.setAttribute("contracts", contracts);
        request.getRequestDispatcher("/views/pawncontract/list.jsp").forward(request, response);

    }

    private void viewContract(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        PawnContractDto contract = pawnContractService.findContractDtoById(id);
        request.setAttribute("contract", contract);
        request.getRequestDispatcher("/views/pawncontract/view.jsp").forward(request, response);

    }

    private void deleteContract(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        pawnContractService.deleteContract(id);
        response.sendRedirect(request.getContextPath() + "/admin/contracts?action=list");
    }

    private void searchContracts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        List<PawnContractDto> results = pawnContractService.searchContractsDto(keyword);
        request.setAttribute("contracts", results);
        request.getRequestDispatcher("/views/pawncontract/list.jsp").forward(request, response);

    }

    private void showUpdateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        PawnContractDto contract = pawnContractService.findContractDtoById(id);
        request.setAttribute("contract", contract);
        request.getRequestDispatcher("/views/pawncontract/update.jsp").forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        try {
            switch (action) {
                case "create":
                    createContract(request, response);
                    break;
                case "update":
                    updateContract(request, response);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/admin/contracts?action=list");
                    break;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("error", "⚠️ Dữ liệu số không hợp lệ.");
            listContracts(request, response);
        }
    }

    private void createContract(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        PawnContract contract = mapRequestToContract(request);
        boolean success = pawnContractService.addContract(contract);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/admin/contracts?action=list");
        } else {
            request.setAttribute("error", "Không thể thêm hợp đồng. Vui lòng thử lại!");
            request.getRequestDispatcher("/views/pawncontract/create.jsp").forward(request, response);

        }
    }

    private void updateContract(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        PawnContract contract = mapRequestToContract(request);
        contract.setPawnContractId(Integer.parseInt(request.getParameter("pawnContractId")));

        boolean success = pawnContractService.updateContract(contract);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/admin/contracts?action=list");
        } else {
            request.setAttribute("error", "Không thể cập nhật hợp đồng. Vui lòng thử lại!");
            request.getRequestDispatcher("/views/pawncontract/update.jsp").forward(request, response);

        }
    }

    // ---- Helper methods ----
    private PawnContract mapRequestToContract(HttpServletRequest request) {
        try {
            request.setCharacterEncoding("UTF-8");
        } catch (Exception ignored) {}

        PawnContract contract = new PawnContract();
        contract.setCustomerId(parseIntSafe(request.getParameter("customerId")));
        contract.setEmployeeId(parseIntSafe(request.getParameter("employeeId")));
        contract.setProductId(parseIntSafe(request.getParameter("productId")));
        contract.setPawnValue(parseDoubleSafe(request.getParameter("pawnPrice")));
        contract.setInterestRate(parseDoubleSafe(request.getParameter("interestRate")));
        contract.setPawnDate(LocalDate.parse(request.getParameter("pawnDate")));
        contract.setDueDate(LocalDate.parse(request.getParameter("dueDate")));

        String returnDateStr = request.getParameter("returnDate");
        if (returnDateStr != null && !returnDateStr.isEmpty()) {
            contract.setReturnDate(LocalDate.parse(returnDateStr));
        }

        contract.setStatus(request.getParameter("status"));
        return contract;
    }

    private int parseIntSafe(String val) {
        return (val == null || val.isEmpty()) ? 0 : Integer.parseInt(val);
    }

    private double parseDoubleSafe(String val) {
        return (val == null || val.isEmpty()) ? 0.0 : Double.parseDouble(val);
    }
}
